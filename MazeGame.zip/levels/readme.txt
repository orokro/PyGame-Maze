Mazes generated from:

https://keesiemeijer.github.io/maze-generator/#generate