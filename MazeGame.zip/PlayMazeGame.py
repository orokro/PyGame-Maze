"""
	PlayMazeGame.py
	---------------

	This will be the main entrypoint to the game, to kick everything off, but otherwise,
	not do much. Everything else will be OOP baby.
"""

# import our main class, and just insantiate it.
from MazeGame import MazeGame

# let's-a-go
game = MazeGame()
