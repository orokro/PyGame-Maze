"""
	Util.py
	-------

	Stores some generic things that are useful, but don't belong anywhere else.
"""

# copied from:
# https://stackoverflow.com/questions/2352181/how-to-use-a-dot-to-access-members-of-dictionary
# makes dict access in python, sane
class dotdict(dict):
    """dot.notation access to dictionary attributes"""
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

